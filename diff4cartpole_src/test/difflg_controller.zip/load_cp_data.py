import os
import pandas as pd
import torch
import numpy as np
from torch.utils.data import Dataset, DataLoader

class MyCPSDataset(Dataset):
    def __init__(self, 
                 start, 
                 end, 
                 binarize=0,
                 norm=False,
                 norm_vec_path="D:\\zihao\\telluride_25\\cp_sim\\dataset\\Trial_14__17_08_2024_for_telluride\\Models\\Dense-7IN-32H1-32H2-1OUT-0\\normalization_vec_a.csv",
                 data_dir="D:\\zihao\\telluride_25\\cp_sim\\dataset\\Trial_14__17_08_2024_for_telluride\\Recordings\\Train\\"):
        """
        Args:
            root_dir (string): Directory with all the Experiment-XXX.csv files.
        """
        self.data = []
        if os.path.exists(norm_vec_path):
            norm_vec = pd.read_csv(norm_vec_path, header=None).values.flatten()
            norm_vec = torch.tensor(norm_vec, dtype=torch.float32)
        else:
            print(f"File {norm_vec_path} does not exist.")
        # Loop through Experiment-091 to -120.csv
        for i in range(start, end):
            file_path = os.path.join(data_dir, f"Experiment-{i:03d}.csv")
            if os.path.exists(file_path):
                # Skip first 38 rows, use row 39 as header
                df = pd.read_csv(file_path, skiprows=38)

                # Select relevant input and output columns
                inputs = df[['angleD', 'angle_cos', 'angle_sin', 'position', 'positionD', 'target_equilibrium', 'target_position']].values
                outputs = df[['Q_calculated_offline']].values

                for x, y in zip(inputs, outputs):
                    if binarize:
                        x = torch.tensor(x, dtype=torch.float32)
                        if norm:
                            x = x * norm_vec
                        # Convert to numpy for bit reinterpretation
                        x_np = x.numpy().view(np.uint32)
                        # Convert each uint32 to bits
                        bits_list = []
                        for val in x_np:
                            bits = np.unpackbits(
                                np.array([val], dtype=np.uint32).view(np.uint8)
                            )
                            bits_list.append(bits)

                        # Concatenate to a single array of shape [224]
                        bits_concat = np.concatenate(bits_list, axis=0)

                        # Convert back to torch tensor if needed
                        bits_tensor = torch.from_numpy(bits_concat)
                        x = bits_tensor.type(torch.float32)
                        if binarize == 1:
                            y = torch.tensor(y, dtype=torch.float32)
                            y_np = y.numpy().view(np.uint32)
                            # Convert each uint32 to bits
                            bits_y_list = []
                            for val in y_np:
                                bits_y = np.unpackbits(
                                    np.array([val], dtype=np.uint32).view(np.uint8)
                                )
                                bits_y_list.append(bits_y)
                            # Concatenate to a single array of shape [32]
                            bits_y_concat = np.concatenate(bits_y_list, axis=0)
                            bits_y_tensor = torch.from_numpy(bits_y_concat)
                            y = bits_y_tensor.type(torch.float32)
                        else:
                            y = torch.tensor(y, dtype=torch.float32)
                        self.data.append((x, y))
                    else:
                        x = torch.tensor(x, dtype=torch.float32) * norm_vec
                        self.data.append((x, torch.tensor(y, dtype=torch.float32)))
            else:
                print(f"File {file_path} does not exist.")

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        return self.data[idx]

# Load normalization vector
# norm_vec_path = "D:\\zihao\\telluride_25\\cp_sim\\dataset\\Trial_14__17_08_2024_for_telluride\\Models\\Dense-7IN-32H1-32H2-1OUT-0\\normalization_vec_a.csv"  # update with your full path if needed
# # Example usage
# train_dir = "D:\\zihao\\telluride_25\\cp_sim\\dataset\\Trial_14__17_08_2024_for_telluride\\Recordings\\Train\\"  # replace with your actual directory path
# train_dataset = MyCPSDataset(start=91, end=121, norm_vec_path=norm_vec_path, data_dir=train_dir)
# test_dir = "D:\\zihao\\telluride_25\\cp_sim\\dataset\\Trial_14__17_08_2024_for_telluride\\Recordings\\Test\\" 
# test_dataset = MyCPSDataset(start=81, end=86, norm_vec_path=norm_vec_path, data_dir=test_dir)

# # Probe how many samples are in the dataset
# print(f"Number of samples in training dataset: {len(train_dataset)}")

# train_loader = DataLoader(train_dataset, batch_size=256, shuffle=True)

# # Test loading
# for batch_inputs, batch_outputs in train_loader:
#     print(batch_inputs.shape, batch_outputs.shape)
#     break